﻿using Business.Models;
using Business.Services;
using Business.Services.Interfaces;
using RepositoryLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace API.Controllers
{
    public class ProductsController : BaseController
    {

        IService productsService = new ProductsService(new ProductsRepository());

        public ProductsController()
        {

        }

        [Route("api/GetProducts")]
        public List<Product> GetProducts()
        {
            var products = productsService.GetProducts();
            return products;
        }

        [Route("api/GetProduct")]
        public Product GetProduct(int productId)
        {
            var product = productsService.GetProduct(productId);
            return product;
        }

        [Route("api/InsertProduct")]
        public bool InsertProduct(Product product)
        {
            var result = productsService.InsertProduct(product);
            return result;
        }

        [Route("api/UpdateProduct")]
        public bool UpdateProduct(Product product)
        {
            var result = productsService.UpdateProduct(product);
            return result;
        }


    }
}
