﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using API.Controllers;
using System.Linq;
using Business.Models;

namespace API.Tests
{
    [TestClass]
    public class ProductsTest
    {
        [TestMethod]
        public void GetProducts_Test()
        {
            //Act
            ProductsController controller = new ProductsController();
            var products = controller.GetProducts();
            //Assert
            Assert.IsTrue(products != null && products.Any());
        }

        [TestMethod]
        public void GetProduct_Test()
        {
            //Arrange
            int productId = 1;
            //Act
            ProductsController controller = new ProductsController();            
            var product = controller.GetProduct(productId);
            //Assert
            Assert.IsTrue(product != null);
        }

        [TestMethod]
        public void AddProduct_Test()
        {
            //Arrange
            Product product = new Product() { Id = 20, Name = "Prod20", Price = 47 };
            //Act
            ProductsController controller = new ProductsController();
            bool result = controller.InsertProduct(product);
            //Assert
            Assert.IsTrue(result);
        }
    }
}
