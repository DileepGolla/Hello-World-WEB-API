﻿using Business.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryLayer.Interfaces
{
    public interface IRepository
    {
        List<Product> GetProducts();

        Product GetProduct(int ProductId);

        bool InsertProduct(Product Product);

        bool UpdateProduct(Product Product);

    }
}
