﻿using RepositoryLayer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Models;

namespace RepositoryLayer
{
    public class ProductsRepository : IRepository
    {
        public List<Product> _products = new List<Product>();

        public ProductsRepository()
        {
            FillProducts();
        }

        public void FillProducts()
        {
            _products.Add(new Product() { Id = 1, Name = "Prod1", Type = "type1", Price = 25 });
            _products.Add(new Product() { Id = 2, Name = "Prod2", Type = "type1", Price = 25 });
            _products.Add(new Product() { Id = 3, Name = "Prod3", Type = "type1", Price = 30 });
            _products.Add(new Product() { Id = 4, Name = "Prod4", Type = "type2", Price = 25 });
            _products.Add(new Product() { Id = 5, Name = "Prod5", Type = "type2", Price = 40 });
            _products.Add(new Product() { Id = 6, Name = "Prod6", Type = "type2", Price = 25 });
        }

        public Product GetProduct(int productId)
        {
            return _products.Where(x => x.Id == productId).FirstOrDefault();
        }

        public List<Product> GetProducts()
        {
            return _products;
        }

        public bool InsertProduct(Product Product)
        {
            if (Product != null && !_products.Any(x => x.Id == Product.Id))
            {
                _products.Add(Product);
                return true;
            }

            return false;
        }

        public bool UpdateProduct(Product product)
        {

            _products.Remove(_products.Where(x => x.Id == product.Id).FirstOrDefault());
            _products.Add(product);

            return true;

        }
    }
}
