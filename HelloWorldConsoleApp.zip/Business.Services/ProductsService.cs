﻿using Business.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Models;
using RepositoryLayer.Interfaces;

namespace Business.Services
{

    public class ProductsService : IService
    {
        IRepository repo;

        public ProductsService(IRepository repository)
        {
            repo = repository;
        }

        public Product GetProduct(int ProductId)
        {
            return repo.GetProduct(ProductId);
        }

        public List<Product> GetProducts()
        {
            return repo.GetProducts();
        }

        public bool InsertProduct(Product Product)
        {
            return repo.InsertProduct(Product);
        }

        public bool UpdateProduct(Product Product)
        {
            return repo.UpdateProduct(Product);
        }
    }
}
