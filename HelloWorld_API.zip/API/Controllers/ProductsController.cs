﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Business.Models;
using Business.Services;
using Business.Services.Interfaces;
using RepositoryLayer;

namespace API.Controllers
{
    public class ProductsController : HomeController
    {
        //we use all the classes and interfaces to create an API
        IService productsService = new ProductsService(new ProductsRepository());
        public ProductsController()
        {

        }
        [HttpGet]
        [Route("api/GetProducts")]
        public List<Product> GetProducts()
        {
            var products = productsService.GetProducts();
            return products;
        }
        [Route("api/GetProduct")]
        public Product GetProduct(int productId)
        {
            var product = productsService.GetProduct(productId);
            return product;
        }
       [HttpPost]
        [Route("api/InsertProduct")]
        public bool InsertProduct([FromBody]Product productId)
        {
            var result = productsService.InsertProduct(productId);
            return result;
        }
        [HttpPut]
        [Route("api/UpdateProduct")]
        public bool UpdateProduct(Product productId)
        {
            var result = productsService.UpdateProduct(productId);
            return result;
        }
        
    }
}
