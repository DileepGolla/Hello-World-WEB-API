﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RepositoryLayer.Interefaces;
using Business.Models;
//All the Database Calls are mentioned here
namespace RepositoryLayer
{
    public class ProductsRepository:IRepository
    {
        /*We will call this list from the API to List,Add,Update and Delete the items
        We can aslo add a database list, in this assignment we are implementing a list*/
        public List<Product> _products = new List<Product>();
        public ProductsRepository() //constructor to insert items when an object is created
        {
            FillProducts();
        }
        public void FillProducts()
        {
            _products.Add(new Product() { Id=1,Name="Prdo1",Type="Type1",Price=5});
            _products.Add(new Product() { Id = 1, Name = "Prdo2", Type = "Type2", Price = 20 });
            _products.Add(new Product() { Id = 1, Name = "Prdo3", Type = "Type3", Price = 35 });
            _products.Add(new Product() { Id = 1, Name = "Prdo4", Type = "Type4", Price = 25 });
            _products.Add(new Product() { Id = 1, Name = "Prdo5", Type = "Type5", Price = 60 });
        }
        public Product GetProduct(int productId)    //gives single item based on Id
        {
            return _products.Where(x=>x.Id==productId).FirstOrDefault();
        }
        public List<Product> GetProducts()  //retursn all the items
        {
            return _products;
        }
        public bool InsertProduct(Product Product)  //creates a new item
        {
            if (Product != null && _products.Any(x => x.Id == Product.Id))
            {
                _products.Add(Product);
                return true;
            }
            else
                return false;
        }
        public bool UpdateProduct(Product Product)  //updates an existing item
        {
            if (Product != null)
            {
                _products.Remove(_products.Where(x => x.Id == Product.Id).FirstOrDefault());
                _products.Add(Product);
                return true;
            }
            else
                return false;
        }
    }
}
