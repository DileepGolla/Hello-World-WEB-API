﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Models;
using RepositoryLayer.Interefaces;
using Business.Services.Interfaces;

namespace Business.Services
{
    public class ProductsService:IService
    {
        //calls to the repository layer are made here 
        IRepository repo;
        public ProductsService(IRepository repository)
        {
            repo = repository;
        }
        //definition of the interface classes
        public Product GetProduct(int ProductId)
        {
            return repo.GetProduct(ProductId);
        }
        public List<Product> GetProducts()
        {
            return repo.GetProducts();
        }
        public bool InsertProduct(Product Product)
        {
            return repo.InsertProduct(Product);
        }
         public bool UpdateProduct(Product Product)
        {
            return repo.UpdateProduct(Product);
        }
    }
}
